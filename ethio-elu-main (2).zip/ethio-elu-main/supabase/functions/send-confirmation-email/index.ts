// Triggered by a Supabase Database Webhook on UPDATE of registration
// (configure in Dashboard > Database > Webhooks — no code needed there).
// Fires on every update to a row, so this function checks that the change
// was specifically an admin approving (approved: false -> true) before
// sending anything — this is what makes "admin must approve before the
// email goes out" actually true, not just a UI suggestion.
//
// Not meant to be called from the browser: it's protected by a shared
// secret header, not by RLS or a user login.
//
// Deploy with:
//   supabase functions deploy send-confirmation-email --no-verify-jwt
//
// Required secrets (supabase secrets set KEY=value):
//   BREVO_API_KEY    — from brevo.com, Settings > SMTP & API > API Keys
//   BREVO_FROM_EMAIL — the sender email you verified in Brevo
//   BREVO_FROM_NAME  — e.g. "Horizon Workforce" (display name, no domain needed)
//   SITE_URL         — e.g. "https://yourdomain.com" (no trailing slash)
//   WEBHOOK_SECRET   — any random string; set the same value as a custom
//                      header (name it e.g. "x-webhook-secret") on the
//                      Database Webhook so only Supabase can trigger this

Deno.serve(async (req) => {
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) {
    return new Response("Unauthorized", { status: 401 });
  }

  const payload = await req.json().catch(() => null);
  const record = payload?.record;
  const oldRecord = payload?.old_record;

  if (!record) {
    return new Response("Bad request", { status: 400 });
  }

  const justApproved = record.approved === true && oldRecord?.approved !== true;
  if (!justApproved) {
    // Some other field changed (status, notes, etc.) — not our concern.
    return new Response("Skipped: not a new approval", { status: 200 });
  }

  if (!record.email) {
    // No email on file — nothing to send. The applicant still has the
    // on-screen link from register.html, so this isn't their only path.
    return new Response("Skipped: no email", { status: 200 });
  }

  const siteUrl = Deno.env.get("SITE_URL");
  const confirmLink = `${siteUrl}/confirm.html?token=${record.confirm_token}`;

  const html = `
  <div style="font-family: -apple-system, Helvetica, Arial, sans-serif; max-width: 480px; margin: 0 auto; background: #F7F5F1;">
    <div style="background: linear-gradient(120deg, #0B1626 0%, #10243E 55%, #16304F 100%); padding: 36px 32px; text-align: center;">
      <p style="color:#C89B3C; font-weight:700; font-size:13px; letter-spacing:0.04em; text-transform:uppercase; margin:0 0 10px;">Horizon Workforce</p>
      <h1 style="color:#F7F5F1; font-size:24px; margin:0;">You're registered! &#127881;</h1>
    </div>
    <div style="background:#FFFFFF; padding: 32px; border: 1px solid #E3DFD6; border-top: none;">
      <p style="color:#33404E; font-size:15px; line-height:1.6;">Hi ${escapeHtml(record.full_name)},</p>
      <p style="color:#33404E; font-size:15px; line-height:1.6;">
        Your registration has been received and is now in our system. There's nothing more you need to do
        right now — our team reviews new registrations against current employer openings and will contact
        you directly if there's a match.
      </p>
      <p style="color:#7C8896; font-size:13px; line-height:1.5;">
        This confirms your registration only — it isn't a job offer or placement.
      </p>
      <div style="text-align:center; margin: 28px 0;">
        <a href="${confirmLink}" style="display:inline-block; background:#10243E; color:#F7F5F1; text-decoration:none; font-weight:600; font-size:14px; padding:13px 26px; border-radius:4px;">
          View my registration status
        </a>
      </div>
      <p style="color:#7C8896; font-size:12px; line-height:1.5;">
        Save this email or the link above — it's how you check your status later.
      </p>
    </div>
    <p style="color:#7C8896; font-size:11px; text-align:center; margin: 18px 0;">
      Horizon Workforce &middot; contact@horizonworkforce.com
    </p>
  </div>`;

  const text = `Hi ${record.full_name},

Your registration has been received and is now in our system.
There's nothing more you need to do right now — our team reviews new registrations
against current employer openings and will contact you directly if there's a match.

This confirms your registration only — it isn't a job offer or placement.

Check your status any time: ${confirmLink}

— Horizon Workforce`;

  const emailBody = {
    sender: {
      email: Deno.env.get("BREVO_FROM_EMAIL"),
      name: Deno.env.get("BREVO_FROM_NAME") || "Horizon Workforce",
    },
    to: [{ email: record.email }],
    subject: "You're registered with Horizon Workforce 🎉",
    htmlContent: html,
    textContent: text,
  };

  const res = await sendWithRetry(emailBody);

  if (!res.ok) {
    console.error("Brevo error:", await res.text());
    return new Response("Email send failed", { status: 502 });
  }

  return new Response("Sent", { status: 200 });
});

async function sendWithRetry(body: unknown, attempts = 3): Promise<Response> {
  let lastRes: Response | null = null;
  for (let i = 0; i < attempts; i++) {
    lastRes = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "api-key": Deno.env.get("BREVO_API_KEY")!,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
    });
    if (lastRes.ok) return lastRes;
    // Only retry on transient errors (rate limit / server-side), not bad requests.
    if (lastRes.status !== 429 && lastRes.status < 500) return lastRes;
    await new Promise((r) => setTimeout(r, 500 * (i + 1)));
  }
  return lastRes!;
}

function escapeHtml(value: string) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}